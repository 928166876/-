#include <iostream>
#include <cstdlib>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <chrono>

const int BUFFER_SIZE = 1;  // 1 MB buffer size
const int DATA_SIZE = 104857600 * BUFFER_SIZE;  // 100 MB data size

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <server_ip> <server_port>" << std::endl;
        return 1;
    }

    const char* server_ip = argv[1];
    int server_port = std::atoi(argv[2]);

    // Create socket
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        std::cerr << "Error creating socket" << std::endl;
        return 1;
    }

    // Set up server address
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    if (inet_pton(AF_INET, server_ip, &server_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address" << std::endl;
        return 1;
    }

    // Connect to server
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        std::cerr << "Error connecting to server" << std::endl;
        return 1;
    }

    char* data_buffer = new char[BUFFER_SIZE];
    memset(data_buffer, 'A', BUFFER_SIZE);

    std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();

    int total_sent = 0;
    while (total_sent < DATA_SIZE) {
        int remaining = DATA_SIZE - total_sent;
        int bytes_to_send = std::min(remaining, BUFFER_SIZE);
        send(client_socket, data_buffer, bytes_to_send, 0);
        total_sent += bytes_to_send;
    }

    std::chrono::steady_clock::time_point end_time = std::chrono::steady_clock::now();
    std::chrono::milliseconds elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);

    double throughput = static_cast<double>(DATA_SIZE) / (elapsed_time.count() / 1000.0) / (1024 * 1024); // MB/s

    std::cout << BUFFER_SIZE << ":" << DATA_SIZE << std::endl;
    std::cout << "Data sent: " << DATA_SIZE / (1024 * 1024) << " MB" << std::endl;
    std::cout << "Elapsed time: " << elapsed_time.count() << " ms" << std::endl;
    std::cout << "Throughput: " << throughput << " MB/s" << std::endl;

    delete[] data_buffer;
    
    // Close the socket
    close(client_socket);

    return 0;
}
