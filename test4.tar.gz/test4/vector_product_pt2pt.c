#include <stdio.h>

#include <mpi.h>

#include "util.h"

#define N 8

int main(int argc, char *argv[])
{
    /* Initiliaze the MPI environment */
    MPI_Init(&argc, &argv);

   /* Obtain the number of proccesses in this parallel program */
    int size;
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    /* Obtain my rank */
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    /* Calculate how many elements of a vector I will hold */
    int elems_per_rank = N/size;
    
    /* Allocate space for the vectors I will hold */
    int *vector_a = NULL;
    int *vector_b = NULL;
    vector_a  = (int *) malloc(elems_per_rank * sizeof(int));
    vector_b  = (int *) malloc(elems_per_rank * sizeof(int));
    
    /* Initialize the vectors */
    /**
     * In a real-world program, you will typically
     * be reading the inputs from a file
     */
    init_vector(vector_a, elems_per_rank, rank);
    init_vector(vector_b, elems_per_rank, rank + size);

    /* Print my inputs */
    print_input(rank, vector_a, vector_b, elems_per_rank);
 
    MPI_Barrier(MPI_COMM_WORLD);

    /* Compute the local product */
    int local_prod = 0;
    for (int i = 0; i < elems_per_rank; i++) {
        local_prod += vector_a[i] * vector_b[i];
    }

    printf("Rank %d local prod: %d\n", rank, local_prod);

    int global_prod = 0;
    if (rank == 0) {
        /* Make space to collect remote products */
        int *remote_prods = NULL;
        remote_prods = (int *) malloc((size-1) * sizeof(int));

        /* Collect local products from all other processes */
        for (int i = 1; i < size; i++) {
            MPI_Recv(&remote_prods[i-1], 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        
        /* Compute global prod */
        global_prod = local_prod;
        for (int i = 0; i < size-1; i++) {
            global_prod += remote_prods[i];
        }

        /* Send global product to other ranks */
        for (int i = 1; i < size; i++) {
            MPI_Send(&global_prod, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
        
        free(remote_prods);
    } else {
        /* Send local prods to the rank that will compute the global prod (rank 0) */
        int aggregating_rank = 0;
        MPI_Send(&local_prod, 1, MPI_INT, aggregating_rank, 0, MPI_COMM_WORLD);
        
        /* Receive the global product */
        MPI_Recv(&global_prod, 1, MPI_INT, aggregating_rank, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    printf("Rank %d: The global product is %d\n", rank, global_prod);

    /* Free up allocated memory */
    free(vector_a);
    free(vector_b);

    /* Terminate the MPI environment */
    MPI_Finalize();

    return 0;
}

