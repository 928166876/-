#include <stdlib.h>
#include <string.h>
#include <time.h>

void init_vector(int *vector, int num_elems, int id)
{
    srand(time(NULL) + id);
    for (int i = 0; i < num_elems; i++) {
        vector[i] = rand() % 10  + 1;
    }
}

void print_input(int rank, int *vec_a, int *vec_b, int nelems)
{
    char input_string[1000];
    
    sprintf(input_string, "Rank %d: A = [%d", rank, vec_a[0]);
    for (int i = 1; i < nelems; i++) {
        sprintf(input_string + strlen(input_string), ",%d", vec_a[i]);
    }
    sprintf(input_string + strlen(input_string), "]; B = [%d", vec_b[0]);
    for (int i = 1; i < nelems; i++) {
        sprintf(input_string + strlen(input_string), ",%d", vec_b[i]);
    }
    sprintf(input_string + strlen(input_string), "]\n");
    printf("%s", input_string);
    fflush(stdout);
}

