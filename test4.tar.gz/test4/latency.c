#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <mpi.h>

#define WARMUP_ITERS    100
#define BENCH_ITERS     1000


int main(int argc, char *argv[])
{
    /* Initiliaze the MPI environment */
    MPI_Init(&argc, &argv);

   /* Obtain the number of proccesses in this parallel program */
    int size;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size != 2) {
        printf("Please run with only 2 processes!\n");
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    if (argc > 2) {
        printf("At most only 1 argument (message size) please!\n");
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    /* Obtain my rank */
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    int message_size = 0;
    if (argc <= 1) {
        /* Use default message size */
        message_size = 8;
    } else {
        /* Read the message size */
        message_size = atoi(argv[1]);
    }
    assert(message_size != 0);
    if (rank == 0) {
        printf("Message size is %d\n", message_size);
    }

    /* Allocate a buffer of size <message_size> bytes */
    char *buffer = NULL;
    buffer = (char *) malloc(message_size * sizeof(char));

    double start, end;
    start = end = 0;
    if (rank == 0) {
        /* Warmup (remove any initial setup costs in low-level network drivers or the network itself) */
        for (int i = 0; i < WARMUP_ITERS; i++) {
            /* Send ping */
            MPI_Send(buffer, message_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
            
            /* Wait for pong back */
            MPI_Recv(buffer, message_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        /* Synchronize before beginning actual test */
        MPI_Barrier(MPI_COMM_WORLD);
        
        start = MPI_Wtime();
        for (int i = 0; i < BENCH_ITERS; i++) {
            /* Send ping */
            MPI_Send(buffer, message_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD);
            
            /* Wait for pong back */
            MPI_Recv(buffer, message_size, MPI_CHAR, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
        end = MPI_Wtime();
    } else {
        /* Warmup (remove any initial setup costs in low-level network drivers or the network itself) */
        for (int i = 0; i < WARMUP_ITERS; i++) {
            /* Wait for ping */
            MPI_Recv(buffer, message_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            /* Send pong back */
            MPI_Send(buffer, message_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
        }

        /* Synchronize before beginning actual test */
        MPI_Barrier(MPI_COMM_WORLD);
        
        for (int i = 0; i < BENCH_ITERS; i++) {
            /* Wait for ping */
            MPI_Recv(buffer, message_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            /* Send pong back */
            MPI_Send(buffer, message_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
        }
    }

    /* Calculate one-way latency and report it */
    if (rank == 0) {
        double round_trip_lat = (end - start) / BENCH_ITERS;
        double one_way_lat = round_trip_lat / 2;
        printf("One-way latency is %f us.\n", one_way_lat * 1e6);
    }

    /* Free up allocated memory */
    free(buffer);
    
    /* Terminate the MPI environment */
    MPI_Finalize();

    return 0;
}

