#include <stdio.h>

#include <mpi.h>

#include "util.h"

#define N 8

int main(int argc, char *argv[])
{
    /* Initiliaze the MPI environment */
    MPI_Init(&argc, &argv);

   /* Obtain the number of proccesses in this parallel program */
    int size;
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    /* Obtain my rank */
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    /* Calculate how many elements of a vector I will hold */
    int elems_per_rank = N/size;
    
    /* Allocate space for the vectors I will hold */
    int *vector_a = NULL;
    int *vector_b = NULL;
    vector_a  = (int *) malloc(elems_per_rank * sizeof(int));
    vector_b  = (int *) malloc(elems_per_rank * sizeof(int));
    
    /* Initialize the vectors */
    /**
     * In a real-world program, you will typically
     * be reading the inputs from a file
     */
    init_vector(vector_a, elems_per_rank, rank);
    init_vector(vector_b, elems_per_rank, rank + size);

    /* Print my inputs */
    print_input(rank, vector_a, vector_b, elems_per_rank);
 
    MPI_Barrier(MPI_COMM_WORLD);

    /* Compute the local product */
    int local_prod = 0;
    for (int i = 0; i < elems_per_rank; i++) {
        local_prod += vector_a[i] * vector_b[i];
    }

    printf("Rank %d local prod: %d\n", rank, local_prod);
 
    /* Make space to receive partial sum from all each process */
    int *partial_prods = NULL;
    partial_prods = (int *) malloc(size * sizeof(int));
    
    /* Gather partial products on all processes */
    MPI_Allgather(&local_prod, 1, MPI_INT, partial_prods, 1, MPI_INT, MPI_COMM_WORLD);
    
    int global_prod = 0;
    for (int i = 0; i < size; i++) {
        global_prod += partial_prods[i];
    }
    
    printf("Rank %d: The global product is %d\n", rank, global_prod);
    
    /* Free up allocated memory */
    free(vector_a);
    free(vector_b);
    free(partial_prods);
    
    /* Terminate the MPI environment */
    MPI_Finalize();

    return 0;
}

